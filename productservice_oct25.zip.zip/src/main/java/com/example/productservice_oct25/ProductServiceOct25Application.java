package com.example.productservice_oct25;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductServiceOct25Application {
    public static void main(String[] args) {
        SpringApplication.run(ProductServiceOct25Application.class, args);
    }
}
